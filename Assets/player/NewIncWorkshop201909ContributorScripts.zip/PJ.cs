using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PJ : Thing
{

    //THIS IS A COMMENT, will be ignored by computer and meant for us humans.
    //text after a double slash is a comment.

    //===========================================================
    //EVENTS, put functions inside the code blocks
    //===========================================================

    //Execute onece when the Thing is spawned
    //Usually for setting up variables
    protected override void ThingAwake()
    {

        //Set flocking variables
        //tips: this is how you call a function and pass a variable into it
        SetAlignmentWeight(8);
        SetCohesionWeight(3);
        SetSeperationWeight(0.5f);

        //10 is the default
        SetMaxSpeed(10);

        //  scale parameters: width, height and depth
        // this is how you do random -> Random.Range(low, high);
        // example: random scale
        // SetScale(new Vector3(Random.Range(1, 3), Random.Range(1, 3), Random.Range(1, 3)));
        SetScale(new Vector3(12, 6, 9));
        //color parameters: Red, Green, BLue -- 0 means NO, 1 means FULL
        ChangeColor(new Color(0.4f, 0.8f, 0.1f));
    }

    //execute once, execute after ThingAwake    
    protected override void ThingStart()
    {
        //produce a chat bubble on top of "me"
        Speak("what do you want from this?!?!?");
    }

    //execute every frame, somewhat between 30-120 times per seconds. 
    //becareful of putting functions here, you might crash the program :)
protected override void ThingUpdate()
    {
        SetMaxSpeed(17);
    }

    
    //max speed , 10 is the default.


    protected override void OnSunset()
    {
        //spark particles around it. parameter: Color.black, Amount.18
        //example: Color.blue or Color.red, or if you want to use RGB: new Color(1,0.2f,1);        
        Spark(Color.blue, 106);
        //create a child, smaller than "me", and less active
        CreateChild();
        CreateChild();CreateChild();

    }

    protected override void OnSunrise()
    {
        //produce a chat bubble on top of "me"
        Speak("what's the daay gon b like!");
    }

    protected override void OnMeetingSomeone(GameObject other)
    {
        //this is how you chain text with variables
        Speak(other.name + "goodbye!");

        Spark(Color.black, 99);
    }
    protected override void OnLeavingSomeone(GameObject other)
    {
        CreateChild();
        CreateChild();CreateChild();CreateChild();CreateChild();
    }

    protected override void OnNeighborSpeaking() { }

    protected override void OnNeigborSparkingParticles() { }


}
