using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FooBear : Thing
{

    //THIS IS A COMMENT, will be ignored by computer and meant for us humans.
    //text after a double slash is a comment.

    //===========================================================
    //EVENTS, put functions inside the code blocks
    //===========================================================

    //Execute onece when the Thing is spawned
    //Usually for setting up variables
    protected override void ThingAwake()
    {

        //Set flocking variables
        //tips: this is how you call a function and pass a variable into it
        SetAlignmentWeight(1.75f);
        SetCohesionWeight(2.5f);
        SetSeperationWeight(3);

        //10 is the default
        SetMaxSpeed(3.7f);

        //  scale parameters: width, height and depth
        // this is how you do random -> Random.Range(low, high);
        // example: random scale
        // SetScale(new Vector3(Random.Range(1, 3), Random.Range(1, 3), Random.Range(1, 3)));
        SetScale(new Vector3(1, 1, 1));
        //color parameters: Red, Green, BLue -- 0 means NO, 1 means FULL
        ChangeColor(new Color(0.35f, 0, 0.75f));
    }

    //execute once, execute after ThingAwake    
    protected override void ThingStart()
    {
        //produce a chat bubble on top of "me"
        Speak("Helloooooo");
    }

    //execute every frame, somewhat between 30-120 times per seconds. 
    //becareful of putting functions here, you might crash the program :)
    protected override void ThingUpdate()
    {
        CreateChild();
    }



    protected override void OnSunset()
    {
        //spark particles around it. parameter: Color, Amount
        //example: Color.blue or Color.red, or if you want to use RGB: new Color(1,0.2f,1);        
        Spark(new Color(0,0.5f,1), 100);
        //create a child, smaller than "me", and less active
        CreateChild();

    }

    protected override void OnSunrise()
    {
        //produce a chat bubble on top of "me"        
        SetScale(new Vector3(0.5f,3,0.75f));
        Speak("Squeeeee!!!!");
        Spark(Color.red, 10);
    }

    protected override void OnMeetingSomeone(GameObject other)
    {
        //this is how you chain text with variables
        Speak(other.name + "What's your deal?");
        SetScale(new Vector3(3f,0.5f,0.25f));
        Spark(Color.blue, 10);
    }
    protected override void OnLeavingSomeone(GameObject other)
    {
        Speak("Did I leave the stove on?");
        CreateChild();
    }

    protected override void OnNeighborSpeaking() 
    { 
          Speak("But why?");
          Spark(Color.green, 10);
    }

    protected override void OnNeigborSparkingParticles() 
    {
        StopMoving(5);
        CreateChild();
        RestartWalking(); 
    }


}
